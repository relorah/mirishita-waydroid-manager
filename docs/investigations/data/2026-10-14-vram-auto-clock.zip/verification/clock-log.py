import pathlib,time,json,sys
root=pathlib.Path(__file__).resolve().parent
d=pathlib.Path('/sys/class/drm/card1/device')
h=next((d/'hwmon').glob('hwmon*'))
start=time.monotonic();duration=float(sys.argv[1])
with (root/'clocks.jsonl').open('w') as out:
 while time.monotonic()-start<duration:
  before=time.monotonic();r={'t':before,'wall':time.time(),'elapsed':before-start,'phase':(root/'phase').read_text().strip()}
  for name,p in {'memory_hz':h/'freq2_input','gpu_hz':h/'freq1_input','gpu_busy':d/'gpu_busy_percent','mem_busy':d/'mem_busy_percent','power_uw':h/'power1_average','temperature_mC':h/'temp1_input','vram_bytes':d/'mem_info_vram_used'}.items():
   try:r[name]=int(p.read_text())
   except (OSError,ValueError):r[name]=None
  try:r['mclk_states']=(d/'pp_dpm_mclk').read_text().strip()
  except OSError:pass
  r['read_time_ms']=(time.monotonic()-before)*1000
  out.write(json.dumps(r)+'\n');out.flush()
  time.sleep(max(0,0.1-(time.monotonic()-before)))
