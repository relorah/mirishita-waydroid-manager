from pathlib import Path
import time,json,sys
r=Path(__file__).resolve().parent;start=time.monotonic();prev=None
h=next(h for h in Path('/sys/class/hwmon').glob('hwmon*') if (h/'name').read_text().strip()=='k10temp')
with (r/'cpu.jsonl').open('w') as out:
 while time.monotonic()-start<float(sys.argv[1]) and not (r/'STOP').exists():
  t=time.monotonic();v={'t':t,'wall':time.time(),'elapsed':t-start,'phase':(r/'phase').read_text().strip()}
  v['cpu_stat']=[x for x in Path('/proc/stat').read_text().splitlines() if x.startswith('cpu')]
  v['temperature_mC']={p.name:int(p.read_text()) for p in h.glob('temp*_input')}
  v['temperature_labels']={p.name:p.read_text().strip() for p in h.glob('temp*_label')}
  v['reported_freq_kHz']={p.name:int((p/'scaling_cur_freq').read_text()) for p in Path('/sys/devices/system/cpu/cpufreq').glob('policy*')}
  v['package_energy_uj']=int(Path('/sys/class/powercap/intel-rapl:0/energy_uj').read_text());v['package_max_energy_uj']=int(Path('/sys/class/powercap/intel-rapl:0/max_energy_range_uj').read_text())
  if prev:
   delta=(v['package_energy_uj']-prev['package_energy_uj'])%v['package_max_energy_uj'];v['package_W']=delta/1e6/(t-prev['t'])
  out.write(json.dumps(v)+'\n');out.flush();prev=v
  time.sleep(max(0,1-(time.monotonic()-t)))
