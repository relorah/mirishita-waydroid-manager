PR #5 最終実機検証・修正キット。フルインストーラーではありません。
通常更新はPR #5マージ後のMWM mainを取得し、既存の正常な環境で通常のinstall.shを使用してください。既存v0.84 Release ZIPはこの深度修正を含みません。
fix/payload/graphicsのoverlayは最終検証済みMesa/GLESアーカイブ。実機では検証後、開始時のv0.84へ復元済みです。
元ソース: https://github.com/relorah/mirishita-waydroid-manager/releases/download/v0.83/MWM_v0.83.zip の MWM_v0.83/payload/sources/graphics-sources.tar.zst (SHA256 6ddc1e4dbf0c5663d2ed70df3c6eed406211cffad6c0f406f53c2e87b236d9dd)。そのソースへsource/mesa-msaa-storage2.patch、source/depth-blit/mesa-depth-only-blit.patchの順で適用し、BUILD.mdとREADME.mdの手順を使用。integrate.pyを再実行しない。
静的リンクlibelfを変更して再リンクする権利と手順を保持。利用者の変更に必要なリバースエンジニアリングやデバッグを禁止しない。上流のファイル別通知・ライセンスはMWM MITと別に適用。
全てのSHA256SUMSを検証してから使用。fix/payload/SHA256SUMSはmain全payload用なので、この差分ZIPだけでは他のoverlayは揃いません。
画面保存ありのx5データを厳密な性能向上の根拠にしない。読み込み区間の約500msはライブの不具合から除外。x6初回の50msは再再生では再現せず、原始データを両方収録。
ゲームデータ、APK、Native Bridge、ゲームshader/IR、私的Android生ログ、アカウントUI、設定バックアップは収録しません。
