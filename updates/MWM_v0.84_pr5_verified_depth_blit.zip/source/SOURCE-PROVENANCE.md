# 再ビルドした描画スタックの出典

この成果物は、9/8 ISO由来と利用者が確認したRTScaleバイナリを比較基準に、RTScale処理を独立に復元したMWM版です。元作者の8月・9月の改造ソースは公開されておらず、ISOのビット単位の再現ではありません。以下の固定ソースから今回の配布バイナリを実際にビルドしました。旧ドナーの描画バイナリは同梱しません。

| 部品 | 今回のビルド元 | 変更 |
| --- | --- | --- |
| Mesa / GLES1・2 / EGL / GBM | Mesa `acbb4f6b8de2768b5ea7d6a83a8e52a263eac5cc`、26.3.0-devel | RTScale復元処理、NativeWindowリンク用スタブ。スタブの共有ライブラリは配布しない |
| LLVM | [Mauro Rossi llvm-project](https://github.com/maurossi/llvm-project)、`dac12ae0ec75c6431275f672da74de9c9f4d68f7`、21.0.0 | ソース変更なし。AMDGPU/X86、Android API30、ABI checks ON |
| libdrm | [2.4.133原本](https://dri.freedesktop.org/libdrm/libdrm-2.4.133.tar.xz)、SHA256 `fc68f9d0ba2ea63c9432a299e14fea09fad7a8a66e8039fcd7802ca59f77b4f5` | Android-x86のgralloc互換用drmOpenByFBを独立実装。データ配置 `/vendor/etc/libdrm/amdgpu.ids` |
| gbm_gralloc | [Rob Herring gbm_gralloc](https://github.com/robherring/gbm_gralloc)、`e74175c1bb3752665776d5b159292524d8d0f60a` | ソース変更なし。Android 11 ABIで再ビルド |
| drm_framebuffer | [remote-android](https://github.com/remote-android/platform_external_drm_framebuffer)、`a818364c4020c120de94983a59ebe90529102626` | ソース変更なし。grallocに静的リンク。lambdadroid由来 |
| Android libelf | [AOSP elfutils](https://android.googlesource.com/platform/external/elfutils)、`5f92182e496a66149ba09c92fe497135643663f5`、Android 11 r48 | Android.bpのlibelf対象115ファイルを静的リンク |
| libc++ヘッダー | [AOSP libcxx](https://android.googlesource.com/platform/external/libcxx)、`a15eefdd3872e1cee0a5b490bfa9573784cbee5f`、Android 11 r48 | locale_bionic.hにAPI26以上のガード |
| Android cutils/logヘッダー | [AOSP system core](https://github.com/aosp-mirror/platform_system_core/tree/android-11.0.0_r48)、android-11.0.0_r48 | ソース変更なし |
| ツールチェーン | [NDK r27c](https://dl.google.com/android/repository/android-ndk-r27c-linux.zip)、Clang18 | Android30 x86_64。NDKは別途取得 |

Androidのlibc++、libhardware、libcutils、liblog、libnativewindow、bionicなどはWaydroidプラットフォームの実装を利用します。コピーした実機バイナリやリンク用スタブをMWMに配布しません。実機のAndroid11 libc++.soはビルド時にもリンク入力として使用します。

RTScale独立復元部分は0BSD。元のRTScale機能を公開し技術解説を提供したmogareta7731氏に感謝します。Mesa、LLVM、libdrm、Android、Rob Herring/Linaro/LunarG、Chia-I Wu、lambdadroid、Mauro Rossi、Chih-Wei Huangおよび各開発者に感謝します。復元・統合・検証はChatGPTおよびCodexを用いて実施しました。

各上流のライセンスは対応するソース内の通知が優先します。libelfを含むソースとビルド手順、LLVMの通知・第三者コード、Mesaのファイル別ライセンスをソースアーカイブに保存します。MWMのMIT Licenseで上流を再ライセンスするものではありません。

0.60.7候補: mutable/immutable画像保持、描画先への接続時拡大、実オブジェクトによるViewport判定、CPU/PBO/GPUコピーと後からの画像転送の寸法保護、接続直後のViewport更新を追加。上流commitは同じで、9/8ドナーへの変更ではなくMWM独立実装への修正です。

## 今回回収した版

このアーカイブはMWM_v0.61_20261004の保存物を基にしている。0.60.7以後の描画先の遅延割当、MSAA、blit矩形、sampler単位のTexelSize等の修正を含む統合済み版である。同保存物の5本の描画overlayアーカイブはv0.83とバイト一致した。今回、ビルドに使わない上流プロジェクト・テストバイナリ・一部テスト資料を除外し、ビルド手順、libelf再リンク手順、libc++のAPI26パッチと各通知を補った。選別内容はSOURCE-CLEANUP.md参照。配布するv0.83の描画ライブラリは入れ替えていない。
