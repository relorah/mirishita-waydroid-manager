# Source package selection

Recovered source archive SHA256: 43b0e6add0c951c6376a5625d7447f655e7fa22bc1fca23c1111dc6b899ffd32.

This package preserves the patched Mesa and RTScale source, LLVM core and its CMake/third-party/runtimes support, libdrm with the drmOpenByFB compatibility addition, gbm_gralloc, drm_framebuffer, Android libelf, libc++ headers, and cutils/log declarations. Build scripts and license notices are included.

Removed: precompiled upstream test fixtures (ELF, APK, ZIP and dump files), unused LLVM subprojects, disabled LLVM/libc++/elfutils tests, unused Mesa Teflon test models, Android system-core components not used for the cutils/log headers, and dangling links into excluded components. No source file needed by the tested build targets was deliberately removed. A full upstream checkout may be needed to run tests outside the MWM build profile. Corresponding fixed upstream revisions are recorded in SOURCE-PROVENANCE.md.

No NDK, host virtual environment, build directory, object/archive/shared library output, platform link-input binary, diagnostic log, user settings, game data, or private credential is included in the source package. The llvm Meson adapter is generated locally by prepare-paths.py.

Checked by path/extension inventory and independently by magic bytes and link targets. Mesa, libelf, libdrm and gralloc build checks used the selected source. LLVM native generation tools and the Android LLVM shared runtime (all library components, AMDGPU/X86, API 30, ABI checks ON) were subsequently built from clean output directories against the reduced source tree. Mesa was also rebuilt and linked successfully with that clean LLVM runtime and its generated headers. MangoApp source remains in the separate vendor archive in the MWM package.
