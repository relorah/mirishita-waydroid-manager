# 描画スタック再ビルド手順

Android11 / API30 / x86_64向け。今回のビルド元はSOURCE-PROVENANCE.md参照。空の作業フォルダに `payload/sources/graphics-sources.tar.zst` を展開し、`docs/graphics-build/` の内容をpatchesサブフォルダを含めてその作業フォルダ直下へコピーする。以後のコマンドはその作業フォルダで実行する。Mesa、libdrm、libcxxは変更適用済みなのでintegrate.py / patch-libdrm.pyを重ねて実行しない。これらは未変更の固定ソースへ変更を適用するために保存している。

NDK r27cをtoolchains/android-ndk-r27cへ展開する。Meson1.12.1、Ninja1.13.2、CMake、Python3、ホストC/C++コンパイラを用意する。実機のAndroid11 system/lib64/libc++.soをbuild-deps/libc++.soへ読み出す。grallocリンク時は `/var/lib/waydroid/rootfs/system/lib64/` のliblog/libcutils/libhardwareを利用する。旧ドナーLLVMは不要。

```sh
mkdir -p toolchains build-deps
cp /var/lib/waydroid/rootfs/system/lib64/libc++.so build-deps/libc++.so
python3 -m venv toolchains/python-env
toolchains/python-env/bin/pip install Mako==1.3.10 PyYAML==6.0.2 packaging==25.0 MarkupSafe==3.0.4
mkdir -p build-deps/lib/pkgconfig build-deps/include stage-llvm/lib
python3 prepare-paths.py
cmake -S toolchains/llvm21/llvm -B toolchains/llvm21-config -G Ninja -DCMAKE_BUILD_TYPE=Release '-DLLVM_TARGETS_TO_BUILD=AMDGPU;X86' -DLLVM_ENABLE_PROJECTS= -DLLVM_INCLUDE_TESTS=OFF -DLLVM_INCLUDE_BENCHMARKS=OFF -DLLVM_ENABLE_RTTI=OFF -DLLVM_ENABLE_ABI_BREAKING_CHECKS=FORCE_ON
cmake --build toolchains/llvm21-config --target llvm-tblgen llvm-headers vt_gen -j8
bash configure-llvm-android.sh
ninja -C build-llvm-android LLVM -j8
cp build-llvm-android/lib/libLLVM.so stage-llvm/lib/libLLVM.so
toolchains/android-ndk-r27c/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip --strip-unneeded stage-llvm/lib/libLLVM.so
```

ABI checks ONは今回のLLVMとMesaの組合せで検証した設定。Android11の__1 libc++ ABIを維持する。新NDK同梱libc++への混在は避ける。

```sh
meson setup build-libdrm toolchains/libdrm-2.4.133 --cross-file android-x86_64.ini --prefix "$PWD/build-deps" --libdir lib --datadir /vendor/etc --buildtype release -Dintel=disabled -Dnouveau=disabled -Dvmwgfx=disabled -Domap=disabled -Dexynos=disabled -Dfreedreno=disabled -Dtegra=disabled -Dvc4=disabled -Detnaviv=disabled -Dtests=false -Dradeon=enabled -Damdgpu=enabled
ninja -C build-libdrm -j8
meson install -C build-libdrm --destdir "$PWD/stage-drm" --no-rebuild
cp -a "stage-drm$PWD/build-deps/." build-deps/
mkdir -p build-deps/share/libdrm
cp stage-drm/vendor/etc/libdrm/amdgpu.ids build-deps/share/libdrm/
python3 build-libelf.py
```

Intel irisのコンパイルではホスト用mesa_clc/vtn_bindgen2が必要。今回のホスト依存はLLVM23.1.1、LLVMSPIRVLib23.1.0.0、SPIRV-Tools2026.3.1。これらはホストのビルド用でAndroid実行依存には入らない。LLVM/Clang開発パッケージ、LLVM-SPIRV translator、SPIRV headers/toolsをホストに用意し次を実行する。

```sh
bash configure-host-clc.sh
bash configure-full-mesa.sh
python3 build-gralloc.py
```

Galliumの指定はradeonsi,iris,crocus,r300,r600,nouveau,svga,virgl,softpipe,llvmpipe,zink。i915は含めない。32bitとAndroidのVulkan ICDは作っていない。Zink自体のビルドを、対応Vulkan ICDや実機での動作確認と取り違えない。

GBMのbackend検索先は `/vendor/lib64`。stage-multigpu/usr/local/lib/gbm/dri_gbm.soをvendor/lib64/dri_gbm.soへ配置する。EGL/GLES1/GLES2はそれぞれlibEGL_mesa.so / libGLESv1_CM_mesa.so / libGLESv2_mesa.soとしてvendor/lib64/eglへ配置する。内部SONAMEはlibEGL.so等のMesa生成名を維持する。LLVMは新しいSONAME libLLVM.soを使用する。旧libLLVM21.soは参照しない。

grallocのビルドに用いたMesaのAndroidヘッダーはAPI宣言用で、スタブ実装はリンクしない。未変更上流ソースから64bitキャストと指定初期化順序の警告が出る。実機起動とバッファ読み書きが通過したが、警告を隠していない。

テスト手順・測定結果・限界は [VALIDATION.md](VALIDATION.md) 参照。再ビルドには作業場所・ツールバージョンに依存するBuild ID等があり、同じソースからのビット単位同一性は検証していない。

MWM 0.60.7のMesa修正は通常画像を保持し、immutable描画先への接続時だけ拡大します。変更適用済みソースと独立RTScale原本、統合用patchを同梱します。診断ログは含みません。


## 配布物の組立とlibelfの再リンク（2026-10-09追記）

ソースアーカイブには変更適用済みソース、ビルドスクリプト、パッチ、ライセンス通知を含む。このアーカイブだけを空の作業ディレクトリへ展開して上の手順を実行できる。NDKと記載したホスト開発パッケージ、およびリンク入力用Androidプラットフォームライブラリは別途用意する。元バイナリのビット単位の再現性は保証しない。libelfのassert文字列にはビルド時の絶対ソースパスが入る。

Mesaライブラリはビルドディレクトリから直接取り出さず、必ず `meson install --destdir` の出力を使用する。Mesonのインストール処理で開発用RUNPATHが除かれる。libdrmはインストール出力を使用し、LLVMとgrallocは記載どおりstripする。Mesa/libdrmへ追加のstripを行うと配布元とのハッシュが変わる。

`package-mwm-payload.py --root /path/to/empty-package` は再ビルド済みライブラリをvendorパスへ組み立て、overlayアーカイブ、12ファイルのマニフェスト、SHA256を生成する。指定先に `payload/graphics` と `payload/manifests` を先に作成する。実機のユーザーデータやインストール先は指定しない。必要に応じ `--mesa-stage /path/to/stage/usr/local/lib` で独立したMesaステージを指定できる。

libelfはlibgallium_dri.soへ静的リンクしている。LGPL-3.0-or-laterを選択して配布し、同梱のGNU LGPLv3/GPLv3とファイル別通知を保持する。利用者は `toolchains/elfutils-android11` のlibelfを変更し、`python3 build-libelf.py`、`ninja -C build-android-multigpu`、`meson install -C build-android-multigpu --destdir "$PWD/stage-multigpu" --no-rebuild` により、変更したlibelfを含むlibgallium_dri.soを再リンクできる。関連するMesaソース、LLVMソース、生成用スクリプト、リンク手順も同梱する。MWMはこの変更に必要なリバースエンジニアリングやデバッグを禁止しない。配布物の上流ライセンスと通知はMWMのMITとは別に適用する。

NDKやAndroidのプラットフォーム実装はこのソースアーカイブに含めない。libc++のローカルヘッダー修正は `patches/libcxx-api26.patch` に記録している。既に適用済みのソースへ重ねて適用しない。
