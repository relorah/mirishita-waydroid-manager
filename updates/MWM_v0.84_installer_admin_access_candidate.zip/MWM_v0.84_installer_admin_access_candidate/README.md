# MWM v0.84 管理者アクセス確認の修正候補

作業ブランチ： https://github.com/relorah/mirishita-waydroid-manager/tree/fix/installer-existing-admin-access
PR： https://github.com/relorah/mirishita-waydroid-manager/pull/4
コミット：1bc45ee2f46e1defb93b99cfabf79c961018941f

既に非対話のsudoアクセスが許可されている場合、それを確認してインストールを進めます。利用できなければ従来と同じsudo -vで認証します。権限設定の追加・拡大はありません。

実機で修正前のパスワード要求によるexit 1を確認し、修正後のapp-only更新と通常インストールがexit 0となること、全設定・管理対象ライブラリの一致、既存backup保持を確認しました。パスワードが必要な環境での対話入力は未確認です。

単体ではインストールできません。v0.84ソース全体とともに使用してください。既存のinstall.shに独自変更がある場合は差分を確認し、上書き前に保存してください。戻す場合は保存したinstall.shを戻します。推奨は上記作業ブランチ全体をダウンロードして通常の更新手順を使うことです。

高速Refreshの修正PR #3とは独立した差分です。描画ライブラリの更新、ゲームデータの変更はこの修正に含まれません。
