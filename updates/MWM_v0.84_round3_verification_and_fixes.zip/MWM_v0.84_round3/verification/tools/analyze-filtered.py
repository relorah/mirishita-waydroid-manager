import json,sys,statistics,re
from pathlib import Path
def percentile(a,p):
    a=sorted(a);i=(len(a)-1)*p/100;l=int(i);return a[l]+(a[min(l+1,len(a)-1)]-a[l])*(i-l)
def clients(text):
    result={}
    for block in text.split('pos:'):
        cid=re.search(r'drm-client-id:\s*(\d+)',block)
        if not cid:continue
        val={k:int(v) for k,v in re.findall(r'drm-engine-(\w+):\s*(\d+) ns',block)}
        result[cid[1]]=val
    return result
path=Path(sys.argv[1]);lo=float(sys.argv[2]);hi=float(sys.argv[3])
rows=[json.loads(x) for x in path.open()];rows=[r for r in rows if lo<=r['elapsed']<=hi]
summary={'file':str(path),'window_seconds':[lo,hi],'samples':len(rows)}
fps=[float(r['fps_cache'].split()[0]) for r in rows]
summary['inactive_cache_not_game_fps']={'mean':statistics.mean(fps),'min':min(fps),'p5':percentile(fps,5),'below50_samples':sum(x<50 for x in fps),'below55_samples':sum(x<55 for x in fps)}
pts={};ready={}
for row in rows:
    valid={}
    for layer,text in row['latency'].items():
        data=[]
        for line in text.splitlines()[1:]:
            cols=line.split()
            if len(cols)==3:
                a,b,c=map(int,cols)
                if 0<b<9e18:data.append((a,b,c))
        if data:valid[layer]=data
    if valid:
        layer=max(valid,key=lambda k:max(x[1] for x in valid[k]))
        for a,b,c in valid[layer]:pts[b]=b;ready[b]=c
origin=rows[0]['t']-rows[0]['elapsed']
times=sorted(t for t in pts if (origin+lo)*1e9<=t<=(origin+hi)*1e9)
dt=[(b-a)/1e6 for a,b in zip(times,times[1:]) if b>a]

if len(times)>1:
    counts=[sum((origin+sec)*1e9<=t<(origin+sec+1)*1e9 for t in times) for sec in range(int(lo),int(hi)) if (origin+sec)*1e9>=times[0] and (origin+sec+1)*1e9<=times[-1]]
    summary['actual_game_fps']={'aggregate':(len(times)-1)*1e9/(times[-1]-times[0]),'one_second_min':min(counts),'one_second_max':max(counts),'p5':percentile(counts,5),'below55_seconds':sum(x<55 for x in counts),'below50_seconds':sum(x<50 for x in counts),'counts':counts}
summary['actual_present_intervals_ms']={'n':len(dt),'mean':statistics.mean(dt),'p95':percentile(dt,95),'p99':percentile(dt,99),'max':max(dt),'above25ms':sum(x>25 for x in dt),'above33ms':sum(x>33 for x in dt)} if dt else {}
for card in rows[0]['gpu']:
    g=[r['gpu'][card] for r in rows]
    summary[card]={}
    for key in ['gpu_busy_percent','mem_busy_percent','mem_info_vram_used','mem_info_gtt_used','power1_average','temp1_input']:
        vals=[int(x[key]) for x in g if key in x]
        if vals:summary[card][key]={'mean':statistics.mean(vals),'max':max(vals)}
memory = []
for row in rows:
    fields = {k: int(v) * 1024 for k, v in re.findall(r'^(MemTotal|MemAvailable|SwapTotal|SwapFree):\s*(\d+) kB', row['memory'], re.M)}
    if 'MemTotal' in fields and 'MemAvailable' in fields:
        fields['used_estimate'] = fields['MemTotal'] - fields['MemAvailable']
        memory.append(fields)
summary['system_memory_bytes'] = {key: {'mean': statistics.mean(x[key] for x in memory), 'min': min(x[key] for x in memory), 'max': max(x[key] for x in memory)} for key in memory[0]} if memory else {}
cpu=[];peakcore=[];engines={}
for before,after in zip(rows,rows[1:]):
    t=after['t']-before['t']
    if t<=0:continue
    prev={s.split()[0]:list(map(int,s.split()[1:])) for s in before['cpu'] if s.startswith('cpu')}
    curr={s.split()[0]:list(map(int,s.split()[1:])) for s in after['cpu'] if s.startswith('cpu')}
    loads={}
    for k,c in curr.items():
        if k not in prev:continue
        d=[x-y for x,y in zip(c[:8],prev[k][:8])];total=sum(d)
        if total>0:loads[k]=100*(total-d[3]-d[4])/total
    if 'cpu' in loads:cpu.append(loads['cpu'])
    if len(loads)>1:peakcore.append(max(v for k,v in loads.items() if k!='cpu'))
    for pid,text in after.get('fdinfo',{}).items():
        a=clients(text);b=clients(before.get('fdinfo',{}).get(pid,''))
        vals={}
        for cid,e in a.items():
            if cid in b:
                for k,v in e.items():vals[k]=vals.get(k,0)+max(0,v-b[cid].get(k,v))/1e9/t*100
        for k,v in vals.items():engines.setdefault(pid+':'+k,[]).append(v)
summary['cpu']={'mean_global':statistics.mean(cpu),'max_global':max(cpu),'max_single_core':max(peakcore)} if cpu else {}
summary['process_gpu_engine_percent']={k:{'mean':statistics.mean(v),'p95':percentile(v,95),'max':max(v)} for k,v in engines.items()}
temps={}
for row in rows:
    for key,value in row.get('cpu_temperature',{}).items(): temps.setdefault(key,[]).append(int(value)/1000)
summary['cpu_temperature_celsius']={k:{'mean':statistics.mean(v),'min':min(v),'max':max(v)} for k,v in temps.items()}
print(json.dumps(summary,indent=2))
