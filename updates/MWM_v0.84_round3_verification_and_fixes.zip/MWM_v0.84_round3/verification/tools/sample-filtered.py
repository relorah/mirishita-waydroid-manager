import time,json,subprocess,pathlib,sys
FDINFO_READER = r"""
import pathlib,sys,re
root=pathlib.Path('/proc')/str(int(sys.argv[1]))
seen=set()
for fd in (root/'fd').iterdir():
    try:
        if not str(fd.readlink()).startswith('/dev/dri/'): continue
        text=(root/'fdinfo'/fd.name).read_text()
        match=re.search(r'drm-client-id:\s*(\d+)',text)
        if not match or match[1] in seen: continue
        seen.add(match[1]); print(text)
    except OSError: pass
"""
root=pathlib.Path('/sys/class/drm')
out=open(sys.argv[1],'w')
duration=float(sys.argv[2])
def rh(*args):
    return subprocess.run(['sudo','-n','/usr/local/libexec/mwm-root-helper',*args],capture_output=True,text=True,timeout=24).stdout
layers=[x for x in rh('sf-list').splitlines() if 'TID:' in x and 'millionlive' in x]
start=time.monotonic()
gamepids=subprocess.run(['pgrep','-f','^com.bandainamcoent.imas_millionlive_theaterdays$'],capture_output=True,text=True).stdout.split()
gspids=subprocess.run(['pgrep','-x','gamescope-wl'],capture_output=True,text=True).stdout.split()
pids=gamepids+gspids
while time.monotonic()-start<duration:
    row={'t':time.monotonic(),'elapsed':time.monotonic()-start,'wall':time.time(),'gpu':{}}
    for c in root.glob('card[0-9]'):
        d=c/'device'; vals={}
        for n in ['gpu_busy_percent','mem_busy_percent','mem_info_vram_used','mem_info_vram_total','mem_info_gtt_used','mem_info_vis_vram_used','pp_dpm_sclk','pp_dpm_mclk']:
            try: vals[n]=(d/n).read_text().strip()
            except OSError: pass
        for h in d.glob('hwmon/hwmon*'):
            for n in ['temp1_input','power1_average','freq1_input','freq2_input']:
                try: vals[n]=(h/n).read_text().strip()
                except OSError: pass
        row['gpu'][c.name]=vals
    row['cpu_temperature']={}
    for h in pathlib.Path('/sys/class/hwmon').glob('hwmon*'):
        try:
            if (h/'name').read_text().strip()=='k10temp': row['cpu_temperature']={p.name:p.read_text().strip() for p in h.glob('temp*_input')}
        except OSError: pass
    row['cpu']=pathlib.Path('/proc/stat').read_text().splitlines()[:33]
    row['memory']=pathlib.Path('/proc/meminfo').read_text()
    row['fps_cache']=pathlib.Path('/home/re/.local/state/mwm/mirishita-fps').read_text().strip()
    row['fps_cache_source']='inactive MangoApp cache when overlay mode is detailed; do not use as game FPS'
    row['overlay_mode']=(pathlib.Path.home()/'.config/mwm/performance-overlay-mode').read_text().strip()
    row['fdinfo']={}
    for pid in pids:
        data=subprocess.run(['sudo','-n','python','-c',FDINFO_READER,str(int(pid))],capture_output=True,text=True).stdout
        row['fdinfo'][pid]=data
    row['latency']={layer:rh('sf-latency',layer) for layer in layers}
    out.write(json.dumps(row)+'\n');out.flush()
    time.sleep(.5)
