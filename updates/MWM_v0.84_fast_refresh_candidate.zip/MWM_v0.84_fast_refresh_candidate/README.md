# MWM v0.84 高速Refresh修正候補

実機で確認した高速Refreshの2件の不具合を修正する差分パッケージです。描画ライブラリやゲームデータは含みません。公開v0.84 Releaseの差替えではありません。

正本の作業ブランチ： https://github.com/relorah/mirishita-waydroid-manager/tree/fix/v084-fast-refresh-runtime
レビュー： https://github.com/relorah/mirishita-waydroid-manager/pull/3
修正コミット：62b93ece453661249a5ba31a7e827ee2b8def65e

対象はv0.84です。推奨更新手順は作業ブランチ全体をダウンロードし、MWM画面を閉じて、既存アプリと設定をバックアップしてから `bash install.sh --update-app` を実行することです。これにより描画payloadと保存設定を保持してアプリを更新できます。

このZIPを既存v0.84ソースに展開する場合、上書き前に `mwm/scripts/rts-fast-state.py` と `mwm/scripts/waydroid-control.sh` を保存してください。変更済みファイルを無条件に上書きしないでください。既存ソースへ2ファイルと回帰テストを反映後、上記app-only更新を実行します。戻す場合は保存した2ファイルを戻してapp-only更新を再実行します。

修正内容：直接起動された状態記録スクリプトのversion.py読込経路と、高速Refresh成功時の二重cleanup。実機の修正前エラー再現・修正後exit 0、Android/Compositor保持、設定変更時の完全再起動、23件の回帰テストを確認しました。通常の対話パスワード入力画面は未確認です。長時間負荷の追加確認は別レポートに記録します。
